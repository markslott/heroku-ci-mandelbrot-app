package io.iron.ironworker.client.codes;

public class JavaCode extends BaseCode {
    public JavaCode(String name, String file) {
        super(name, file, "sh", "__runner__.sh");
    }
}
