package com.sfdc.msl.mandelbrot;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import io.iron.ironworker.client.Client;
import io.iron.ironworker.client.entities.TaskEntity;
import io.iron.ironworker.client.builders.Params;
import io.iron.ironworker.client.APIException;

/**
 * This program will queue up several image creation workers,
 * wait for them to complete, then queue up an aggregation worker
 * All image output is stored in Amazon S3
 * 
 * @author Mark Lott
 *
 */
public class Enqueue {

	
	/*
	 * When you create your Heroku instance and add the Iron_Worker add on, you 
	 * can get these values by running the following command:
	 * 
	 * heroku config --app <your Heroku app name> | grep IRON
	 * 
	 */
	private static final String IRON_WORKER_PROJECT_ID = "";
	private static final String IRON_WORKER_TOKEN = "";
	
	private static final String AMAZON_S3_BUCKETNAME = "mlott-sfdc-s3-bucket-0001";
	
	/*
	 * I like these values because they make for an attractive picture.
	 * But feel free to experiment.
	 * You can try XPOS = -3, YPOS = 2, SIZE = 2 to get a view of the whole set.
	 */
	private static final double FRACTAL_XPOS = -0.2392231;
	private static final double FRACTAL_YPOS = 0.6502145012;
	private static final double FRACTAL_SIZE = 0.0004854988;
	
	/*
	 * How big of a mosaic do you want to make?
	 */
	private static final int MOSAIC_NUM_COLS = 3;
	private static final int MOSAIC_NUM_ROWS = 2;

	/**
	 * Enqueue.main
	 * 
	 * Executing this program will use the IronWorker API to queue up
	 * several jobs to build a series of images that can be combined into a larger 
	 * mosaic.
	 * Once the images are computed and stored in the Amazon S3 cloud, this program
	 * will create another worker that will download the images, combine them into a single
	 * image, and upload it back to Amazon S3
	 * 
	 * In general, you should be able to create a 3X2 image in a couple of minutes.
	 * 
	 * @param args  No args required
	 * @throws APIException
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws APIException,
			InterruptedException {
		Client client = new Client(IRON_WORKER_TOKEN, IRON_WORKER_PROJECT_ID);
		// create a mosaic of fractal images XX by YY wide starting at point at
		// top left of top left image
		int XX = MOSAIC_NUM_COLS, YY = MOSAIC_NUM_ROWS;

		// Set parameters determining location and size of fractal within the
		// Mandelbrot set
		double xpos = FRACTAL_XPOS;
		double ypos = FRACTAL_YPOS;
		
		//This is where we will keep our list of task ids so we can track them.
		List<String> tasks = new ArrayList<String>();
		
		/*
		 * This is where we spin up the image creation workers
		 * There will be XX * YY number of workers created.
		 * On a developer license, try to keep that number under 50 or some
		 * of your work might not get done.
		 */
		int i = 1;
		for (int y = 1; y <= YY; y++) {
			for (int x = 1; x <= XX; x++) {
				TaskEntity t = client.createTask(
						"mandelbrot",
						Params.add("xpos", Double.toString(xpos))
								.add("ypos", Double.toString(ypos))
								.add("size", Double.toString(FRACTAL_SIZE))
								.add("imgid", Integer.toString(i))
								.add("bucketname", AMAZON_S3_BUCKETNAME));
				System.out.println(t.getId());
				tasks.add(t.getId());
				xpos += FRACTAL_SIZE;
				i++;
			}
			ypos -= FRACTAL_SIZE;
			xpos = FRACTAL_XPOS;
		}
		
		/*
		 * This is where we wait for all of the tasks to complete
		 * Basically we are blocking until all the work is done 
		 * before we start the aggregation worker.
		 */
		boolean tasksCompleted = false;
		while (!tasksCompleted) {
			Iterator<String> taskIterator = tasks.iterator();
			tasksCompleted = true;
			while (taskIterator.hasNext()) {
				String taskid = taskIterator.next();
				TaskEntity task = client.getTask(taskid);
				System.out.println("Task " + task.getId() + "has status of "
						+ task.getStatus());
				if (!task.getStatus().equals("complete"))
					tasksCompleted = false;
			}
			if (!tasksCompleted) {
				System.out.println("Sleeping for 10 seconds...");
				Thread.sleep(10000);
			}
		}
		
		/*
		 * Submit another task to make the mosaic.
		 * When this task is complete, the our work is done.
		 */
		TaskEntity t = client.createTask(
				"mandelbrot",
				Params.add("aggregate", "true")
						.add("xsize", Integer.toString(XX))
						.add("ysize", Integer.toString(YY))
						.add("bucketname", AMAZON_S3_BUCKETNAME));
		String aggregator_taskid = t.getId();
		System.out.println("Aggregator task = " + aggregator_taskid);
		
		/*
		 * Check on the status of the aggregation worker
		 * Once complete, check for the aggregated image in 
		 * your Amazon S3 bucket.
		 */
		tasksCompleted = false;
		while (!tasksCompleted) {
			TaskEntity task = client.getTask(aggregator_taskid);
			System.out.println("Task " + task.getId() + "has status of " + task.getStatus());
			if (task.getStatus().equals("complete"))
			   tasksCompleted = true;
			else {
				System.out.println("Sleeping for 10 seconds...");
				Thread.sleep(10000);
			}
		}
	}
}
