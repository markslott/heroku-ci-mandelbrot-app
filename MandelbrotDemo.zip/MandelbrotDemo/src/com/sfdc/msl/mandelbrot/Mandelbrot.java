package com.sfdc.msl.mandelbrot;

/**
 * Mandelbrot Set Demo for Heroku and IronWorker
 * 
 * Shows Heroku used in a computationally intensive context.
 * 
 * Source code borrowed from the public domain
 * Depends on StdDraw.java and Picture.java
 * Demo created by Mark Lott on 1/31/2013
 * 
 * **/

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import javax.imageio.ImageIO;
import org.apache.commons.math3.complex.Complex;
import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import edu.princeton.graphics.Picture;

/**
 * <b>This class is the Worker class for the Iron_Worker addon</b>
 * All of the fun is in here.
 * 
 * This class is intended to be called by the IronWorker to either
 * create a new fractal image or to aggregate images into a mosaic.
 * 
 * Don't forget to put in your access token and secret in the 
 * AwsCredentials.properties file, or you will not be able to store
 * content in your Amazon S3 account.
 * 
 * Code for this was liberally taken from open source projects and examples.
 * 
 * @author Mark Lott
 * 
 */
public class Mandelbrot {

	/*
	 * Changing the color resolution will affect the smoothness of the color transitions
	 * lower numbers (like 16) have bigger differences between the color shades.  
	 * Larger numbers (like 256) are pretty smooth.
	 */
	private static final float[] blue = Color.blue.getRGBComponents(null);
	private static final float[] white = Color.white.getRGBComponents(null);
	private static final float[] yellow = Color.yellow.getRGBComponents(null);
	private static final float[] red = Color.red.getRGBComponents(null);
	private static final float[][] colorCycle = { blue, white, yellow, red };
	private static final int colorResolution = 256;

	/*
	 * Tweaks here will change the size of the image and the total amount of zoom
	 * you can get.  More iterations mean you can zoom deeper.
	 */
	private static final int max = 100000; // maximum number of iterations
	private static final int N = 512; // will create an image of NxN in size

	

	/**
	 * Returns a color based on the number of iterations
	 * This method is needed to make full use of the color spectrum and have pretty 
	 * fractal images. Otherwise everything will look monochrome and washed out.
	 * @param iterations
	 * @return RGB color generated from the color map
	 */
	private static int getColor(int iterations) {
		if (iterations == max) {
			return 0; // black
		}

		float[] from;
		float[] to;
		int colorIndex = 0;
		int iterationsFloat = iterations;
		int colorRes = colorResolution;

		while (iterationsFloat > colorRes) {
			iterationsFloat -= colorRes;
			colorRes = colorRes << 1;
			colorIndex++;
		}
		from = colorCycle[colorIndex % colorCycle.length];
		to = colorCycle[(colorIndex + 1) % colorCycle.length];
		float fraction = iterationsFloat / (float) colorRes;
		int[] res = new int[3];

		// interpolate between from and to color

		for (int i = 0; i < 3; i++) {
			float delta = to[i] - from[i];
			res[i] = (int) ((from[i] + delta * fraction) * 255);
		}
		return ((res[0]) << 16) + ((res[1]) << 8) + (res[2]);
	}

	/**
	 * Reads a file and stores the contents in a string
	 * @param path Path to file being read
	 * @return Contents of file
	 * @throws IOException
	 */
	private static String readFileIntoString(String path) throws IOException {
		FileInputStream stream = new FileInputStream(new File(path));
		try {
			FileChannel chan = stream.getChannel();
			MappedByteBuffer buf = chan.map(FileChannel.MapMode.READ_ONLY, 0,
					chan.size());
			return Charset.defaultCharset().decode(buf).toString();
		} finally {
			stream.close();
		}
	}

	/**
	 * This method will copy the image files stored in Amazon S3 to the local filesystem
	 * This is used by the aggregator to build out the mosaic.
	 * This method also assumes the names of the files stored on Amazon S3
	 * @param numfiles Total number of files that need to be downloaded.
	 * @param bucketName Amazon S3 bucket that is holding the files.
	 */
	private static void copyImagesFromAmazonS3ToLocal(int numfiles, String bucketName) {
		AmazonS3 s3 = new AmazonS3Client(
				new ClasspathPropertiesFileCredentialsProvider(
						"/com/sfdc/msl/mandelbrot/AwsCredentials.properties"));
		try {
			for (int imgid = 1; imgid <= numfiles; imgid++) {
				S3Object object = s3.getObject(new GetObjectRequest(bucketName,
						"mandelbrotimg_" + imgid + ".png"));
				OutputStream out = new FileOutputStream(new File(
						"mandelbrotimg_" + imgid + ".png"));
				InputStream inputStream = (InputStream) object
						.getObjectContent();
				byte[] bytes = new byte[1024];
				int read = 0;
				while ((read = inputStream.read(bytes)) != -1) {
					out.write(bytes, 0, read);
				}
				inputStream.close();
				out.flush();
				out.close();
			}
		} catch (AmazonServiceException ase) {
			System.out
					.println("Caught an AmazonServiceException, which means your request made it "
							+ "to Amazon S3, but was rejected with an error response for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out
					.println("Caught an AmazonClientException, which means the client encountered "
							+ "a serious internal problem while trying to communicate with S3, "
							+ "such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Creates an aggregate image of XX by YY images.  This method is called after
	 * the individual Mandelbrot Set images have been created and stored in Amazon S3
	 * 
	 * @param XX total number of columns in mosaic
	 * @param YY total number of rows in mosaic
	 * @param bucketName name of the bucket storing the mosaic images
	 * @throws IOException
	 */
	private static void createAggregateImage(int XX, int YY, String bucketName)
			throws IOException {
		int rows = YY; // we assume the no. of rows and cols are known and each
					   // chunk has equal width and height
		int cols = XX;
		int chunks = rows * cols;

		int chunkWidth, chunkHeight;
		int type;

		// download files from S3
		copyImagesFromAmazonS3ToLocal(XX * YY, bucketName);

		// fetch local image files
		File[] imgFiles = new File[chunks];
		for (int i = 0; i < chunks; i++) {
			int fileindex = i + 1;
			imgFiles[i] = new File("mandelbrotimg_" + fileindex + ".png");
		}
		
		// creating a buffered image array from image files
		BufferedImage[] buffImages = new BufferedImage[chunks];
		for (int i = 0; i < chunks; i++) {
			System.out.println("Reading " + imgFiles[i].getAbsolutePath());
			buffImages[i] = ImageIO.read(imgFiles[i]);
		}
		type = buffImages[0].getType();
		chunkWidth = buffImages[0].getWidth();
		chunkHeight = buffImages[0].getHeight();

		// Initializing the final image
		BufferedImage finalImg = new BufferedImage(chunkWidth * cols,
				chunkHeight * rows, type);

		int num = 0;
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				finalImg.createGraphics().drawImage(buffImages[num],
						chunkWidth * j, chunkHeight * i, null);
				num++;
			}
		}
		System.out.println("Image concatenated.....");
		File mosaicFile = new File("mandelbrot_mosaic.png");
		ImageIO.write(finalImg, "png", mosaicFile);

		// copy new mosaic file back out to Amazon S3
		saveToAmazonS3(bucketName, "mandelbrot_mosaic.png", mosaicFile);
	}

	/**
	 * This method will run the computations to determine if a point is in the 
	 * Mandelbrot Set and assign a color based on the number of iterations
	 * Once the image is completed, it will be stored on Amazon S3
	 * 
	 * @param xc The x-axis (or real number axis) for the center of the generated image
	 * @param yc The y-axis (or imaginary number axis) for the center of the generated image
	 * @param size The granularity of the image.  smaller numbers are more zoomed in that bigger ones
	 * @param imgid Identifier for the image - needed when creating a mosaic
	 * @param bucketName Name of bucket file will be stored in on Amazon S3
	 */
	private static void createComputedFractalImage(double xc, double yc, double size,
			int imgid, String bucketName) {
		Picture pic = new Picture(N, N);
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				double x0 = xc - size / 2 + size * i / N;
				double y0 = yc - size / 2 + size * j / N;
				Complex z0 = new Complex(x0, y0);
				Color color = new Color(getColor(mand(z0, max)));
				pic.set(i, N - 1 - j, color);
			}
		}

		String key = "mandelbrotimg_" + imgid + ".png";
		File picFile = new File("mandelbrotimg_" + imgid + ".png");
		pic.save(picFile);
		// pic.show();
		// save in Amazon S3 cloud storage
		saveToAmazonS3(bucketName, key, picFile);
	}

	/**
	 * Saves an image file on Amazon S3
	 * @param bucketName Name of bucket to store files
	 * @param key Name of the file on Amazon S3
	 * @param picFile Handle to the local image file
	 */
	private static void saveToAmazonS3(String bucketName, String key,
			File picFile) {
		AmazonS3 s3 = new AmazonS3Client(
				new ClasspathPropertiesFileCredentialsProvider(
						"/com/sfdc/msl/mandelbrot/AwsCredentials.properties"));
		try {
			PutObjectRequest objReq = new PutObjectRequest(bucketName, key,
					picFile);
			ObjectMetadata objMetadata = new ObjectMetadata();
			objMetadata.setContentType("image/png");
			objMetadata.setContentLength(picFile.length());
			objReq.setMetadata(objMetadata);
			s3.putObject(objReq);
		} catch (AmazonServiceException ase) {
			System.out
					.println("Caught an AmazonServiceException, which means your request made it "
							+ "to Amazon S3, but was rejected with an error response for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out
					.println("Caught an AmazonClientException, which means the client encountered "
							+ "a serious internal problem while trying to communicate with S3, "
							+ "such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		}
	}

	/**
	 * IronWorker requires that the parameters be passed in as JSON.  This method will
	 * read the JSON formatted file following the "-payload" command line option
	 * command line option.
	 * 
	 * If running this locally, you'd pass in -payload <file name to JSON formatted params>
	 * @param args 
	 * @return
	 */
	private static String getPayloadFromArgs(String[] args) {
		int payloadPos = -1;
		for (int i = 0; i < args.length; i++) {
			if (args[i].equals("-payload")) {
				payloadPos = i + 1;
				break;
			}
		}
		if (payloadPos >= args.length) {
			System.err.println("Invalid payload argument.");
			System.exit(1);
		}
		if (payloadPos == -1) {
			System.err.println("No payload argument.");
			System.exit(1);
		}

		// read the contents of the file to a string
		String payload = "";
		try {
			payload = readFileIntoString(args[payloadPos]);
		} catch (IOException e) {
			System.err.println("IOException");
			System.exit(1);
		}
		return payload;
	}

	/**
	 * This is the computationally intense part!
	 * return number of iterations to check if c = a + ib is in Mandelbrot set
	 * @param z0
	 * @param max
	 * @return number of iterations to diverge - smoothed out for pretty colors
	 */
	private static int mand(Complex z0, int max) {
		Complex z = z0;
		for (int t = 0; t < max; t++) {
			if (z.abs() > 2.0) {
				// return t; // this is non smooth.
				// smooth coloring algorithm below.  makes better looking pictures:
				double t_smooth = t + 1 - Math.log(Math.log(z.abs()))
						/ Math.log(2);
				return (int) t_smooth;
			}
			z = z.multiply(z).add(z0);
		}
		return max;
	}

	/**
	 * Mandelbrot.main
	 * 
	 * This is called by the IronWorker Heroku addon.  It takes in a JSON formatted
	 * parameter set and does one of two things:
	 * a) If it the aggregate parameter is not set, it will build a fractal image
	 * using the xpos, ypos, and size parameters and store that image in Amazon S3
	 * -or-
	 * b) If the aggregate parameter is set, it will instead aggregate the individual
	 * images into a larger mosaic.
	 * 
	 * The intent is for the Enqueue class to spin up several image creation workers, 
	 * wait for them to complete, then spin up an aggregation worker to weave the individual images
	 * into a single image.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		//initialize params based on params passed in to the worker
		double xc, yc, size;
		int imgid;
		String bucketName;
		String payload = getPayloadFromArgs(args);
	
		Gson gson = new Gson();
		JsonParser parser = new JsonParser();
		JsonObject passed_args = parser.parse(payload).getAsJsonObject();
	
		bucketName = gson.fromJson(passed_args.get("bucketname"), String.class);
		String aggregatePics = gson.fromJson(passed_args.get("aggregate"),
				String.class);

	
		// if we are aggregating, do that then exit
		if (aggregatePics != null) {
			int xx = Integer.parseInt(gson.fromJson(passed_args.get("xsize"),
					String.class));
			int yy = Integer.parseInt(gson.fromJson(passed_args.get("ysize"),
					String.class));
			try {
				createAggregateImage(xx, yy, bucketName);
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.exit(0);
		}
	
		// otherwise we are going to make a picture.
		xc = Double.parseDouble(gson.fromJson(passed_args.get("xpos"),
				String.class));
		yc = Double.parseDouble(gson.fromJson(passed_args.get("ypos"),
				String.class));
		size = Double.parseDouble(gson.fromJson(passed_args.get("size"),
				String.class));
		imgid = Integer.parseInt(gson.fromJson(passed_args.get("imgid"),
				String.class));
	
		createComputedFractalImage(xc, yc, size, imgid, bucketName);
	
	}
}
